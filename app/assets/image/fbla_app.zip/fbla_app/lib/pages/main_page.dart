import 'dart:convert';

import 'package:fbla_app/pages/screens/activites.dart';
import 'package:fbla_app/pages/screens/assignments.dart';
import 'package:fbla_app/pages/screens/calendar.dart';
import 'package:fbla_app/pages/screens/email.dart';
import 'package:fbla_app/pages/screens/errorfeedback.dart';
import 'package:fbla_app/pages/screens/lunchh.dart';
//import 'package:fbla_app/pages/screens/luunch.dart';
import 'package:fbla_app/pages/screens/motivate.dart';
import 'package:fbla_app/pages/screens/schedule.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
//import '../../utils/colors.dart';
//import '../widgets/big_text.dart';
//import 'home/home_page.dart';

class MainPage extends StatefulWidget {
  const MainPage({Key? key}) : super(key: key);

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {

 List info=[];
  _initData(){
   DefaultAssetBundle.of(context).loadString("json/info.json").then((value) {
     info= json.decode(value);
    });
  }

  @override
  void initState(){
    super.initState();

    _initData();
    //print("Length:" + info.length.toString());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: Container(
        decoration: BoxDecoration(
          /*  gradient: LinearGradient(
              colors: [
                Color(0xff2855ae),
                Color(0xff7292cf),
               // Colors.lightBlueAccent,
              ],
              begin: const FractionalOffset(0.0, 0.4),
              end: Alignment.topLeft,
            )
                */
          image: DecorationImage(
            image: AssetImage(
              "assets/image/btwo.png"
            ),
            fit: BoxFit.cover,
          ),
        ),


        child: Column(
          children: [
            Container(

              //
              margin: const EdgeInsets.only(top: 20, left: 30, right: 30),
              width: MediaQuery.of(context).size.width,
              height: 145,
              child: Column(
                children: [
                  //back arrow and profile
                  Row(
                      children: [
                        //back arrow
                        GestureDetector(

                          onTap: (){
                            //motive page once enter into the app
                            Get.to(()=>MotivePage());
                        },
                          child: Icon(
                            //back arrow to go bak to the log in page
                            Icons.arrow_back_ios, size: 30, color: Colors.white,),
                        ),

                        SizedBox(width: 110,),
                        Container(
                          height: 93,
                            width: 60,

                            decoration: BoxDecoration(
                                //color: Colors.white,
                                image: DecorationImage(
                                  alignment: Alignment.topCenter,

                                  image: AssetImage(
                                      "assets/image/logo.png"

                                  ),
                                )
                            ),

                        ),
                        Expanded(child: Container()),
                        Container(
                          height: 93,
                          width: 55,
                                //color: Colors.white,
                                alignment: Alignment.bottomCenter,
                                child: Icon(Icons.account_circle, size: 60,
                                  color: Color(0xffffd8ff),

                                ),

                          ),
                        SizedBox(width: 15),


                      ]
                  ),
                  //SizedBox(height: 10,),
                  //homescreen and profile
                  Row(
                    children: [
                      //homepage title text
                      Text("Home Screen",
                        style: TextStyle(
                            fontSize: 35,
                            color: Colors.white,
                            fontWeight: FontWeight.w800
                        ),
                      ),
                      //space so icons show up on either end of screen
                      Expanded(child: Container(),),
                      //logo showing
                      Container(
                        child: Container(width: 80,
                          height: 20,
                          decoration: BoxDecoration(
                            color: Color(0xfff5f6fc),
                            borderRadius: BorderRadius.circular(10,),
                          ),

                          //creating account widget and settings icon
                          child: Container(
                              child: Row(
                                  children: [
                                    Text("  Account",
                                      style: TextStyle(
                                          fontSize: 15,
                                          color: Color(0xff345fb4),
                                          fontWeight: FontWeight.w400
                                      ),
                                    ),
                                    Icon(Icons.settings, size: 12,  color: Color(0xff345fb4),),
                                  ],

                              ),

                          ),
                        ),
                      )
                      //SizedBox(width:20,),
                    ],
                  ),
                ],
              ),
            ),

            //background with the main white part of page
            Expanded(child: Container(
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    //can make he white backgorund part of page skewed if change one
                    topRight:Radius.circular(40),
                    topLeft: Radius.circular(40),
                  ),
              ),

              //getting the different pages from 6 main page icons
              child: Column(
                children: [
                  SizedBox(height: 20),
                  //first row--includes the scheduling and assignments feature
                  Row(
                    children :[
                      //schedule
                      GestureDetector(
                        onTap: (){
                          Get.to(()=>SchedulePage());
                        },
                        child:  Container(
                          width: 170,
                          height: 125,
                          margin: EdgeInsets.only( left: 25, bottom: 17),

                          decoration: BoxDecoration(
                            color: Color(0xffcbdce8),
                            //0xffdbdbe7),
                            borderRadius: BorderRadius.circular(30),
                            image: DecorationImage(
                              image: AssetImage(
                                  "assets/image/one.png"
                                //"assets/image/Calender.jpg"
                              ),

                            ),


                            //shadow on side and botom
                            boxShadow: [
                              BoxShadow(
                                blurRadius: 5,
                                offset: Offset(5, 5),
                                color: Color(0xffd0d0d0),
                              ),
                            ],


                          ),


                          child: Container(
                            padding: EdgeInsets.only(top: 30, left: 30, right: 15),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(height: 5,),





                                SizedBox(height: 10,),
                              ],
                            ),
                          ),


                        ),
                      ),
                      //assignments
                      GestureDetector(

                        onTap: (){
                          Get.to(()=>AssignPage());
                        },
                        child:  Container(
                          width: 170,
                          height: 125,
                          margin: EdgeInsets.only( left: 25, bottom: 17),

                          decoration: BoxDecoration(
                            color: Color(0xffcbdce8),
                            //0xffdbdbe7),
                            borderRadius: BorderRadius.circular(30),
                            image: DecorationImage(
                              image: AssetImage(
                                  "assets/image/two.png"
                                //"assets/image/Calender.jpg"
                              ),

                            ),


                            //shadow on side and botom
                            boxShadow: [
                              BoxShadow(
                                blurRadius: 5,
                                offset: Offset(5, 5),
                                color: Color(0xffd0d0d0),
                              ),
                            ],


                          ),


                          child: Container(
                            padding: EdgeInsets.only(top: 30, left: 30, right: 15),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(height: 5,),





                                SizedBox(height: 10,),
                              ],
                            ),
                          ),


                        ),
                      ),
                    ],
                  ),

                  //second row --includes the activities and calender
                  Row(
                    children: [
                      //activities
                      GestureDetector(

                        onTap: (){
                          Get.to(()=>ActPage());
                        },
                        child:  Container(
                          width: 170,
                          height: 125,
                          margin: EdgeInsets.only( left: 25, bottom: 17),

                          decoration: BoxDecoration(
                            color: Color(0xffcbdce8),
                            //0xffdbdbe7),
                            borderRadius: BorderRadius.circular(30),
                            image: DecorationImage(
                              image: AssetImage(
                                  "assets/image/act.png"
                                //"assets/image/Calender.jpg"
                              ),

                            ),


                            //shadow on side and botom
                            boxShadow: [
                              BoxShadow(
                                blurRadius: 5,
                                offset: Offset(5, 5),
                                color: Color(0xffd0d0d0),
                              ),
                            ],


                          ),


                          child: Container(
                            padding: EdgeInsets.only(top: 30, left: 30, right: 15),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(height: 5,),





                                SizedBox(height: 10,),
                              ],
                            ),
                          ),


                        ),
                      ),
                      //calender
                      GestureDetector(

                        onTap: (){
                          Get.to(()=>CalPage());
                        },
                        child:  Container(
                          width: 170,
                          height: 125,
                          margin: EdgeInsets.only( left: 25, bottom: 17),

                          decoration: BoxDecoration(
                            color: Color(0xffcbdce8),
                            //0xffdbdbe7),
                            borderRadius: BorderRadius.circular(30),
                            image: DecorationImage(
                              image: AssetImage(
                                  "assets/image/cal.png"
                                //"assets/image/Calender.jpg"
                              ),

                            ),


                            //shadow on side and botom
                            boxShadow: [
                              BoxShadow(
                                blurRadius: 5,
                                offset: Offset(5, 5),
                                color: Color(0xffd0d0d0),
                              ),
                            ],


                          ),


                          child: Container(
                            padding: EdgeInsets.only(top: 30, left: 30, right: 15),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(height: 5,),





                                SizedBox(height: 10,),
                              ],
                            ),
                          ),


                        ),
                      ),
                    ],
                  ),

                  //third row-- inclued the last emial fature and lunch menu
                  Row(
                    children: [
                      //lunch menu
                      GestureDetector(

                        onTap: (){
                          Get.to(()=>LunchPage());
                        },
                        child:  Container(
                          width: 170,
                          height: 125,
                          margin: EdgeInsets.only( left: 25, bottom: 17),

                          decoration: BoxDecoration(
                            color: Color(0xffcbdce8),
                            //0xffdbdbe7),
                            borderRadius: BorderRadius.circular(30),
                            image: DecorationImage(
                              image: AssetImage(
                                  "assets/image/men.png"
                                //"assets/image/Calender.jpg"
                              ),

                            ),


                            //shadow on side and botom
                            boxShadow: [
                              BoxShadow(
                                blurRadius: 5,
                                offset: Offset(5, 5),
                                color: Color(0xffd0d0d0),
                              ),
                            ],


                          ),


                          child: Container(
                            padding: EdgeInsets.only(top: 30, left: 30, right: 15),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(height: 5,),





                                SizedBox(height: 10,),
                              ],
                            ),
                          ),


                        ),
                      ),
                      //email
                      GestureDetector(

                        onTap: (){
                          Get.to(()=>EmailPage());
                        },
                        child:  Container(
                          width: 170,
                          height: 125,
                          margin: EdgeInsets.only( left: 25, bottom: 17),

                          decoration: BoxDecoration(
                            color: Color(0xffcbdce8),
                            //0xffdbdbe7),
                            borderRadius: BorderRadius.circular(30),
                            image: DecorationImage(
                              image: AssetImage(
                                  "assets/image/mail.png"
                                //"assets/image/Calender.jpg"
                              ),

                            ),


                            //shadow on side and botom
                            boxShadow: [
                              BoxShadow(
                                blurRadius: 5,
                                offset: Offset(5, 5),
                                color: Color(0xffd0d0d0),
                              ),
                            ],


                          ),


                          child: Container(
                            padding: EdgeInsets.only(top: 30, left: 30, right: 15),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(height: 5,),





                                SizedBox(height: 10,),
                              ],
                            ),
                          ),


                        ),
                      ),
                    ],
                  ),


              //social media icons and widgets
                  Container(
                    height: 38,
                    width: 360,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(15),
                      color: Color(0xffe5e9ee),
                    ),
                    //padding: ,
                    child: Container(
                      padding: EdgeInsets.only(top: 3, left: 25, right: 15),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children:[
                              Text( "School Socials:",

                                style: TextStyle(
                                  fontSize: 18,
                                  color: Colors.black,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),

                              Container(
                                  width: 30,
                                  height: 30,
                                  margin: EdgeInsets.only(left: 25, bottom: 5),

                                  decoration: BoxDecoration(
                                      image: DecorationImage(
                                          fit: BoxFit.cover,
                                          image: AssetImage(
                                            "assets/image/facebook.png",

                                            //'https://img.icons8.com/material-rounded/344/instagram-new.png',
                                          )
                                      )
                                  )


                              ),
                              Container(
                                  width: 30,
                                  height: 30,
                                  margin: EdgeInsets.only(left: 10, bottom: 5),

                                  decoration: BoxDecoration(
                                      image: DecorationImage(
                                          fit: BoxFit.cover,
                                          image: AssetImage(
                                            "assets/image/instagram.png",

                                            //'https://img.icons8.com/ios-glyphs/344/facebook-new.png',
                                          )
                                      )
                                  )


                              ),
                              Container(
                                  width: 30,
                                  height: 30,
                                  margin: EdgeInsets.only(left: 10, bottom: 5),

                                  decoration: BoxDecoration(
                                      image: DecorationImage(
                                          fit: BoxFit.cover,
                                          image: AssetImage(
                                            "assets/image/web.png",
                                          )
                                      )
                                  )


                              ),

                            ]
                          )


                        ],
                      ),
                    ),



                  ),
                  GestureDetector(
                    onTap:(){
                      Get.to(()=>FeedbackPage());
                    },
                    child: Row(
                        children: [
                          SizedBox(width:125,height: 30),
                          //homepage title text
                          Center(
                              child: Align(
                                  alignment: Alignment.bottomCenter,
                                  child: Text(
                                    "Report A Bug/Feedback",

                                    style: TextStyle(
                                        decoration: TextDecoration.underline,
                                        decorationStyle: TextDecorationStyle.double,
                                        fontSize: 15,
                                        color: Colors.black,
                                        fontWeight: FontWeight.w600
                                    ),
                                  ),
                              )
                          )


                        ]
                    ),
                  ),

                ],
              ),

            ))

          ],
        ),
      ),
    );
  }
}
