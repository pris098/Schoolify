import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import '../../utils/dimensions.dart';
import '../main_page.dart';
import 'enter.dart';
import 'motivate.dart';
import 'schoollist.dart';

class LogIn extends StatefulWidget {
  const LogIn({Key? key}) : super(key: key);

  @override
  State<LogIn> createState() => _LogInState();
}

class _LogInState extends State<LogIn> {
  bool isChecked = false;
  bool isHidden = true;

  static List<SchoolModel>main_school_list = [
  SchoolModel("Woodinville High School"),
  SchoolModel("North Creek High School"),
  SchoolModel("Bothell High School"),
  SchoolModel("Ingelmoore High School"),
  SchoolModel("Redmond High School"),
  SchoolModel("Leota Middle School"),
  SchoolModel("Northshore Middle School"),
  ];
  List<SchoolModel> display_list = List.from(main_school_list);
  void updateList(String value){
    //function that filters the list

  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        //background image
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage("assets/image/btwo.png"),
            fit: BoxFit.cover,
          ),
        ),

        child: Column(
          children: [
            Container(
              margin: const EdgeInsets.only(top: 20, left: 30, right: 30),
              width: MediaQuery.of(context).size.width,
              height: 310,
              child: Column(
                children: [
                  //back arrow and profile
                  SizedBox(height: 20),

                  Row(
                    children: [
                      //back arrow
                      GestureDetector(
                        onTap: () {
                          Get.to(() => EnterPage());
                        },
                        child: Icon(
                          Icons.arrow_back_ios,
                          size: 30,
                          color: Colors.white,
                        ),
                      ),
                      //space
                      Expanded(child: Container(),),
                      //title text


                    ],
                  ),
                  Row(
                    children:[
                      Expanded(child: Container(),),
                      Container(
                      height: 150,
                      width: 150,
                      decoration: BoxDecoration(
                          image: DecorationImage(
                            alignment: Alignment.topCenter,
                            image: AssetImage("assets/image/logo.png"),
                          )),
                    ),
                      Expanded(child: Container(),),
                    ],

                  ),
                  SizedBox(height: 7,),
                  Container(
                    alignment: Alignment.topLeft,
                    child:

                    Text(
                      " Hey Student!",
                      style: TextStyle(
                        color: Colors. white,
                        fontSize: 45,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  SizedBox(height: 5,),
                  Text(
                    "Please sign in using your school email",
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.white70,
                      // fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Container(
                width: Dimensions.screenWidth,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topRight: Radius.circular(40),
                    topLeft: Radius.circular(40),
                  ),
                ),

                child: Column(
                  children: [

                Container(
                margin: EdgeInsets.only(left:30, right: 30, top:25),

                child: Column(

                  children: [
                  Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                      child: Column(
                        children:[
                          TextField(
                            decoration: InputDecoration(
                                border: OutlineInputBorder(),
                                labelText: 'Enter Your School',
                                //hintText: 'Woodinville High School',
                                prefixIcon: Icon(Icons.search)
                            ),
                          ),

                          /*Expanded(
                            child: ListView.builder(
                              itemCount:7,
                              itemBuilder: (context, index) => ListTile(
                                  title: Text(display_list[index].school_title!
                                  )
                              ),
                            ),
                          ),*/

                        ],
                      )

                      ),

                    const Padding(
                      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                      child: TextField(
                        decoration: InputDecoration(
                          border: OutlineInputBorder(),
                          labelText: 'Enter Your School Email',

                          prefixIcon: Icon(Icons.email)
                        ),
                      ),
                    ),
                    //SizedBox(height: 10),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                      child: TextFormField(
                       // controller: widget.controller,
                        obscureText: isHidden,
                        decoration: InputDecoration(
                            border: OutlineInputBorder(),
                            labelText: 'Password',
                            //hintText: '',
                            prefixIcon: Icon(Icons.lock),
                          suffixIcon: IconButton(
                            icon:
                              isHidden ? Icon(Icons.visibility_off) : Icon(Icons.visibility),
                            onPressed: togglePasswordVisibility,

                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                    Row(
                      children: [Checkbox(value: isChecked, onChanged: (value){
                        setState(()=> isChecked = value!);
                      }),
                      Text(
                        "Save", style: TextStyle(fontSize: 15),
                      ),
                      Expanded(child: Container(),),
                        Text(
                          "Forgot Password?", style: TextStyle(fontSize: 15),
                        ),


                      ],

                    ),
                    SizedBox(height: 10),

                    GestureDetector(
                      onTap: (){
                        Get.to(()=>MotivePage());
                      },
                      child: Container(
                        alignment: Alignment.center,
                        width: 300,
                        height: 50,
                        decoration: BoxDecoration(
                          color: Color(0xff2855ae),
                          borderRadius: BorderRadius.circular(15),
                        ),

                        child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children:[

                              Text(
                                "Continue",
                                style: TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.w300,
                                  color: Colors.white,
                                ),
                              ),
                              SizedBox(width: 7,),
                              Icon(Icons.arrow_forward, color: Colors.white)
                            ]
                        ),
                      ),
                    ),

                  ],
                ),
                ),





                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
  void togglePasswordVisibility() => setState(()=> isHidden = !isHidden);

}

class MySearchDelegate extends SearchDelegate{
  @override
  List<Widget>? buildActions(BuildContext context) {
    // TODO: implement buildActions
    throw UnimplementedError();
  }

  @override
  Widget? buildLeading(BuildContext context) {
    // TODO: implement buildLeading
    throw UnimplementedError();
  }

  @override
  Widget buildResults(BuildContext context) {
    // TODO: implement buildResults
    throw UnimplementedError();
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    // TODO: implement buildSuggestions
    throw UnimplementedError();
  }

}