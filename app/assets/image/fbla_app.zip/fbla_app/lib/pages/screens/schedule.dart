import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import '../main_page.dart';

class SchedulePage extends StatefulWidget {
  const SchedulePage({Key? key}) : super(key: key);




  @override
  State<SchedulePage> createState() => _SchedulePageState();
}

class _SchedulePageState extends State<SchedulePage> {
  //List<String> items = ['Computer Science','Mathematics','English','Science','Social Studies','Art','Business','Lunch Break', 'Elective', 'Other'];
  String selectedItem1= 'Computer Science';
  String selectedItem2= 'Mathematics';
  String selectedItem3= 'English';
  String selectedItem4= 'Science';
  String selectedItem5= 'Social Studies';
  String selectedItem6= 'Elective';
  String selectedItem7= 'Elective';



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(

        //background image
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage(
                "assets/image/btwo.png"),
            fit: BoxFit.cover,
          ),
        ),

        child: Column(
          children: [
            Container(
              margin: const EdgeInsets.only(top: 20, left: 30, right: 30),
              width: MediaQuery.of(context).size.width,
              height: 95,
              child: Column(
                children: [
                  //back arrow and profile
                  Row(
                    children: [
                      //back arrow
                      Expanded(child: Container()),

                      Container(
                        height: 50,
                        width: 50,

                        decoration: BoxDecoration(
                            image: DecorationImage(
                              alignment: Alignment.topCenter,

                              image: AssetImage(
                                  "assets/image/logo.png"
                              ),
                            )
                        ),
                      ),
                    ],
                  ),




                  Row(
                    children: [
                      //back arrow
                      GestureDetector(
                        onTap: (){
                          Get.to(()=>MainPage());
                        },
                        child: Icon(
                          Icons.arrow_back_ios, size: 30, color: Colors.white,),
                      ),
                      //space
                      SizedBox(width: 30,),
                      //title text
                      Text("Schedule",
                        style: TextStyle(
                            fontSize: 35,
                            color: Colors.white,
                            fontWeight: FontWeight.w800
                        ),
                      ),

                    ],
                  ),
                ],
              ),
            ),

            Expanded(child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topRight:Radius.circular(40),
                  topLeft: Radius.circular(40),
                ),
              ),

              
                child: SingleChildScrollView(
                  child: Column(

                    children: [
                      Container(
                        margin: EdgeInsets.only(left:20, right: 30, top:30),

                        child: Column(

                          children: [

                            Stack(
                              children:[
                                Container(
                                  alignment: Alignment.center,
                                  height:20,
                                  width: 400,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(15),
                                      border: Border.all(width: 2, color: Colors.black26)

                                  ),
                                ),

                                Column(
                                  children: [
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      crossAxisAlignment: CrossAxisAlignment.center,

                                      children:[
                                        SizedBox(height:5),
                                        Text(
                                          " MON        TUE        WED        THU        FRI",
                                          style: TextStyle(
                                            fontSize: 17,
                                            color: Colors.black45,
                                          ),
                                        ),
                                      ],
                                    ),

                                  ],
                                ),
                                Container(
                                  height: 20,
                                  width: 75,

                                  decoration: BoxDecoration(

                                    color: Color(0xff4980c7),//6789CA
                                    borderRadius: BorderRadius.circular(15),

                                  ),
                                  child: Text(
                                    "    MON", style: TextStyle(
                                    fontSize: 17,
                                    color: Colors.white,
                                  ),
                                  ),
                                ),





                              ],
                            ),
                            SizedBox(height: 10),

                            
                            //period1
                            Container(
                                padding: EdgeInsets.only(left: 17, right: 10),
                              alignment: Alignment.topLeft,
                              height: 120,
                              width: 400,

                              decoration: BoxDecoration(

                                border: Border.all(width: 2, color: Colors.black26),
                                borderRadius: BorderRadius.circular(15),

                              ),
                              child: Column(

                                children: [
                                  Row(
                                    children: [
                                      DropdownButton<String>(
                                        value: selectedItem1,
                                        icon: const Icon(Icons.arrow_drop_down, size: 20),
                                        //elevation: 16,
                                        style: const TextStyle(color: Colors.black, fontSize: 20),
                                        /*underline: Container(
                                          height: 2,
                                          color: Colors.deepPurpleAccent,
                                        ),*/
                                        onChanged: (String? newValue) {
                                          setState(() {
                                            selectedItem1 = newValue!;
                                          });
                                        },
                                        items: <String>['Computer Science','Mathematics','English','Science','Social Studies','Art','Business','Lunch Break', 'Elective', 'Other']
                                            .map<DropdownMenuItem<String>>((String value) {
                                          return DropdownMenuItem<String>(
                                            value: value,
                                            child: Text(value),
                                          );
                                        }).toList(),
                                      ),
                                    ],
                                  ),

                                  SizedBox(height: 5),
                                  Row(children: [
                                    Text(
                                      "08:15am - 09:00am", style: TextStyle(
                                      fontSize: 17,
                                      fontWeight: FontWeight.w400,
                                      color: Colors.black45,
                                    ),
                                    ),

                                  ],),

                                  Divider(
                                    color: Colors.black26,
                                    height: 20,
                                    thickness: 2,
                                    indent: 10,
                                    endIndent: 10,
                                  ),
                                  Row(
                                    children: [
                                     SizedBox(width: 250),
                                      Text(
                                        "Period 1", style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.w400,
                                        color: Colors.black,
                                      ),
                                      ),
                                    ],
                                  )
                                ],
                              )
                            ),
                            SizedBox(height: 5),
                            //period2
                            Container(
                                padding: EdgeInsets.only(left: 17, right: 10),
                                alignment: Alignment.topLeft,
                                height: 120,
                                width: 400,

                                decoration: BoxDecoration(

                                  border: Border.all(width: 2, color: Colors.black26),
                                  borderRadius: BorderRadius.circular(15),

                                ),
                                child: Column(

                                  children: [
                                    Row(
                                      children: [
                                        DropdownButton<String>(
                                          value: selectedItem2,
                                          icon: const Icon(Icons.arrow_drop_down, size: 20),
                                          //elevation: 16,
                                          style: const TextStyle(color: Colors.black, fontSize: 20),
                                          /*underline: Container(
                                          height: 2,
                                          color: Colors.deepPurpleAccent,
                                        ),*/
                                          onChanged: (String? newValue) {
                                            setState(() {
                                              selectedItem2 = newValue!;
                                            });
                                          },
                                          items: <String>['Computer Science','Mathematics','English','Science','Social Studies','Art','Business','Lunch Break', 'Elective', 'Other']
                                              .map<DropdownMenuItem<String>>((String value) {
                                            return DropdownMenuItem<String>(
                                              value: value,
                                              child: Text(value),
                                            );
                                          }).toList(),
                                        ),
                                      ],
                                    ),

                                    SizedBox(height: 5),
                                    Row(children: [
                                      Text(
                                        "09:00am - 09:45am", style: TextStyle(
                                        fontSize: 17,
                                        fontWeight: FontWeight.w400,
                                        color: Colors.black45,
                                      ),
                                      ),

                                    ],),

                                    Divider(
                                      color: Colors.black26,
                                      height: 20,
                                      thickness: 2,
                                      indent: 10,
                                      endIndent: 10,
                                    ),
                                    Row(
                                      children: [
                                        SizedBox(width: 250),
                                        Text(
                                          "Period 2", style: TextStyle(
                                          fontSize: 18,
                                          fontWeight: FontWeight.w400,
                                          color: Colors.black,
                                        ),
                                        ),
                                      ],
                                    )
                                  ],
                                )
                            ),
                            SizedBox(height: 5),
                            //period3
                            Container(
                                padding: EdgeInsets.only(left: 17, right: 10),
                                alignment: Alignment.topLeft,
                                height: 120,
                                width: 400,

                                decoration: BoxDecoration(

                                  border: Border.all(width: 2, color: Colors.black26),
                                  borderRadius: BorderRadius.circular(15),

                                ),
                                child: Column(

                                  children: [
                                    Row(
                                      children: [
                                        DropdownButton<String>(
                                          value: selectedItem3,
                                          icon: const Icon(Icons.arrow_drop_down, size: 20),
                                          //elevation: 16,
                                          style: const TextStyle(color: Colors.black, fontSize: 20),
                                          /*underline: Container(
                                          height: 2,
                                          color: Colors.deepPurpleAccent,
                                        ),*/
                                          onChanged: (String? newValue) {
                                            setState(() {
                                              selectedItem3 = newValue!;
                                            });
                                          },
                                          items: <String>['Computer Science','Mathematics','English','Science','Social Studies','Art','Business','Lunch Break', 'Elective', 'Other']
                                              .map<DropdownMenuItem<String>>((String value) {
                                            return DropdownMenuItem<String>(
                                              value: value,
                                              child: Text(value),
                                            );
                                          }).toList(),
                                        ),
                                      ],
                                    ),

                                    SizedBox(height: 5),
                                    Row(children: [
                                      Text(
                                        "09:45am - 10:30am", style: TextStyle(
                                        fontSize: 17,
                                        fontWeight: FontWeight.w400,
                                        color: Colors.black45,
                                      ),
                                      ),

                                    ],),

                                    Divider(
                                      color: Colors.black26,
                                      height: 20,
                                      thickness: 2,
                                      indent: 10,
                                      endIndent: 10,
                                    ),
                                    Row(
                                      children: [
                                        SizedBox(width: 250),
                                        Text(
                                          "Period 3", style: TextStyle(
                                          fontSize: 18,
                                          fontWeight: FontWeight.w400,
                                          color: Colors.black,
                                        ),
                                        ),
                                      ],
                                    )
                                  ],
                                )
                            ),
                            SizedBox(height: 5),

                            //period4
                            Container(
                                padding: EdgeInsets.only(left: 17, right: 10),
                                alignment: Alignment.topLeft,
                                height: 120,
                                width: 400,

                                decoration: BoxDecoration(

                                  border: Border.all(width: 2, color: Colors.black26),
                                  borderRadius: BorderRadius.circular(15),

                                ),
                                child: Column(

                                  children: [
                                    Row(
                                      children: [
                                        DropdownButton<String>(
                                          value: selectedItem4,
                                          icon: const Icon(Icons.arrow_drop_down, size: 20),
                                          //elevation: 16,
                                          style: const TextStyle(color: Colors.black, fontSize: 20),
                                          /*underline: Container(
                                          height: 2,
                                          color: Colors.deepPurpleAccent,
                                        ),*/
                                          onChanged: (String? newValue) {
                                            setState(() {
                                              selectedItem4 = newValue!;
                                            });
                                          },
                                          items: <String>['Computer Science','Mathematics','English','Science','Social Studies','Art','Business','Lunch Break', 'Elective', 'Other']
                                              .map<DropdownMenuItem<String>>((String value) {
                                            return DropdownMenuItem<String>(
                                              value: value,
                                              child: Text(value),
                                            );
                                          }).toList(),
                                        ),
                                      ],
                                    ),

                                    SizedBox(height: 5),
                                    Row(children: [
                                      Text(
                                        "10:30am - 11:45am", style: TextStyle(
                                        fontSize: 17,
                                        fontWeight: FontWeight.w400,
                                        color: Colors.black45,
                                      ),
                                      ),

                                    ],),

                                    Divider(
                                      color: Colors.black26,
                                      height: 20,
                                      thickness: 2,
                                      indent: 10,
                                      endIndent: 10,
                                    ),
                                    Row(
                                      children: [
                                        SizedBox(width: 250),
                                        Text(
                                          "Period 4", style: TextStyle(
                                          fontSize: 18,
                                          fontWeight: FontWeight.w400,
                                          color: Colors.black,
                                        ),
                                        ),
                                      ],
                                    )
                                  ],
                                )
                            ),
                            SizedBox(height: 5),
                            //period5
                            Container(
                                padding: EdgeInsets.only(left: 17, right: 10),
                                alignment: Alignment.topLeft,
                                height: 120,
                                width: 400,

                                decoration: BoxDecoration(

                                  border: Border.all(width: 2, color: Colors.black26),
                                  borderRadius: BorderRadius.circular(15),

                                ),
                                child: Column(

                                  children: [
                                    Row(
                                      children: [
                                        DropdownButton<String>(
                                          value: selectedItem5,
                                          icon: const Icon(Icons.arrow_drop_down, size: 20),
                                          //elevation: 16,
                                          style: const TextStyle(color: Colors.black, fontSize: 20),
                                          /*underline: Container(
                                          height: 2,
                                          color: Colors.deepPurpleAccent,
                                        ),*/
                                          onChanged: (String? newValue) {
                                            setState(() {
                                              selectedItem5 = newValue!;
                                            });
                                          },
                                          items: <String>['Computer Science','Mathematics','English','Science','Social Studies','Art','Business','Lunch Break', 'Elective', 'Other']
                                              .map<DropdownMenuItem<String>>((String value) {
                                            return DropdownMenuItem<String>(
                                              value: value,
                                              child: Text(value),
                                            );
                                          }).toList(),
                                        ),
                                      ],
                                    ),

                                    SizedBox(height: 5),
                                    Row(children: [
                                      Text(
                                        "11:45am - 12:15pm", style: TextStyle(
                                        fontSize: 17,
                                        fontWeight: FontWeight.w400,
                                        color: Colors.black45,
                                      ),
                                      ),

                                    ],),

                                    Divider(
                                      color: Colors.black26,
                                      height: 20,
                                      thickness: 2,
                                      indent: 10,
                                      endIndent: 10,
                                    ),
                                    Row(
                                      children: [
                                        SizedBox(width: 250),
                                        Text(
                                          "Period 5", style: TextStyle(
                                          fontSize: 18,
                                          fontWeight: FontWeight.w400,
                                          color: Colors.black,
                                        ),
                                        ),
                                      ],
                                    )
                                  ],
                                )
                            ),
                            SizedBox(height: 5),
                            //period6
                            Container(
                                padding: EdgeInsets.only(left: 17, right: 10),
                                alignment: Alignment.topLeft,
                                height: 120,
                                width: 400,

                                decoration: BoxDecoration(

                                  border: Border.all(width: 2, color: Colors.black26),
                                  borderRadius: BorderRadius.circular(15),

                                ),
                                child: Column(

                                  children: [
                                    Row(
                                      children: [
                                        DropdownButton<String>(
                                          value: selectedItem6,
                                          icon: const Icon(Icons.arrow_drop_down, size: 20),
                                          //elevation: 16,
                                          style: const TextStyle(color: Colors.black, fontSize: 20),
                                          /*underline: Container(
                                          height: 2,
                                          color: Colors.deepPurpleAccent,
                                        ),*/
                                          onChanged: (String? newValue) {
                                            setState(() {
                                              selectedItem6 = newValue!;
                                            });
                                          },
                                          items: <String>['Computer Science','Mathematics','English','Science','Social Studies','Art','Business','Lunch Break', 'Elective', 'Other']
                                              .map<DropdownMenuItem<String>>((String value) {
                                            return DropdownMenuItem<String>(
                                              value: value,
                                              child: Text(value),
                                            );
                                          }).toList(),
                                        ),
                                      ],
                                    ),

                                    SizedBox(height: 5),
                                    Row(children: [
                                      Text(
                                        "01:00pm - 01:45pm", style: TextStyle(
                                        fontSize: 17,
                                        fontWeight: FontWeight.w400,
                                        color: Colors.black45,
                                      ),
                                      ),

                                    ],),

                                    Divider(
                                      color: Colors.black26,
                                      height: 20,
                                      thickness: 2,
                                      indent: 10,
                                      endIndent: 10,
                                    ),
                                    Row(
                                      children: [
                                        SizedBox(width: 250),
                                        Text(
                                          "Period 6", style: TextStyle(
                                          fontSize: 18,
                                          fontWeight: FontWeight.w400,
                                          color: Colors.black,
                                        ),
                                        ),
                                      ],
                                    )
                                  ],
                                )
                            ),
                            SizedBox(height: 5),
                            //period7
                            Container(
                                padding: EdgeInsets.only(left: 17, right: 10),
                                alignment: Alignment.topLeft,
                                height: 120,
                                width: 400,

                                decoration: BoxDecoration(

                                  border: Border.all(width: 2, color: Colors.black26),
                                  borderRadius: BorderRadius.circular(15),

                                ),
                                child: Column(

                                  children: [
                                    Row(
                                      children: [
                                        DropdownButton<String>(
                                          value: selectedItem7,
                                          icon: const Icon(Icons.arrow_drop_down, size: 20),
                                          //elevation: 16,
                                          style: const TextStyle(color: Colors.black, fontSize: 20),
                                          /*underline: Container(
                                          height: 2,
                                          color: Colors.deepPurpleAccent,
                                        ),*/
                                          onChanged: (String? newValue) {
                                            setState(() {
                                              selectedItem7 = newValue!;
                                            });
                                          },
                                          items: <String>['Computer Science','Mathematics','English','Science','Social Studies','Art','Business','Lunch Break', 'Elective', 'Other']
                                              .map<DropdownMenuItem<String>>((String value) {
                                            return DropdownMenuItem<String>(
                                              value: value,
                                              child: Text(value),
                                            );
                                          }).toList(),
                                        ),
                                      ],
                                    ),

                                    SizedBox(height: 5),
                                    Row(children: [
                                      Text(
                                        "01:45pm - 02:30pm", style: TextStyle(
                                        fontSize: 17,
                                        fontWeight: FontWeight.w400,
                                        color: Colors.black45,
                                      ),
                                      ),

                                    ],),

                                    Divider(
                                      color: Colors.black26,
                                      height: 20,
                                      thickness: 2,
                                      indent: 10,
                                      endIndent: 10,
                                    ),
                                    Row(
                                      children: [
                                        SizedBox(width: 250),
                                        Text(
                                          "Period 7", style: TextStyle(
                                          fontSize: 18,
                                          fontWeight: FontWeight.w400,
                                          color: Colors.black,
                                        ),
                                        ),
                                      ],
                                    ),







                       //////////            /////////////
                                  ],
                                )
                            ),



                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              
            ),
            ),
          ],
        ),
      ),
    );
  }
}
