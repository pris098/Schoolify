import 'dart:convert';

import 'package:dots_indicator/dots_indicator.dart';
import 'package:fbla_app/widgets/big_text.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../listvalues.dart';
import '../../utils/colors.dart';
import '../../utils/dimensions.dart';


class LunchBody extends StatefulWidget {
  const LunchBody({Key? key}) : super(key: key);

  @override
  State<LunchBody> createState() => _LunchBodyState();
}

class _LunchBodyState extends State<LunchBody> {
//json stuff
  List info=[];
  _initData(){
    DefaultAssetBundle.of(context).loadString("json/info.json").then((value) {
      info= json.decode(value);
    });
  }





  PageController pageController = PageController(viewportFraction: 0.85);
  var _currPageValue = 0.0;
  double _scaleFactor = 0.8;
  double _height = Dimensions.pageViewContainer;

  //code for the differnce in height for scrollable feature
  @override
  void initState() {
    super.initState();
    _initData();
    print("info equals" + info.length.toString());


    pageController.addListener(() {
      setState(() {
        _currPageValue = pageController.page!;
        print("info equals" + info.length.toString());
      });
    });
  }

  @override
  void dispose() {
    pageController.dispose();
  }

  Widget build(BuildContext context) {
    return Column(
      children: [
        //background blue is already imported through the lunch main dart file
        //slider section--codes for white background over blue
       Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.only(
              //curve on the white can be offswed by changing only one radius
              topRight:Radius.circular(40),
              topLeft: Radius.circular(40),
            ),
          ),

          //codes for the title above the slider section
          child: Column(
            children: [
              SizedBox(height: 30,),
              Container(
                //padding on ends
                margin: EdgeInsets.only(left: 30,),
                child: Row(
                  //not center
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    BigText(text: "Daily Lunch Menu Specials:", color: Color(0xff1a247d),)
                  ],
                ),
              ),
              //blackish line below title to create distinguished
              Divider(
                color: Colors.black26,
                height: 20,
                thickness: 2,
                indent: 30,
                endIndent: 30,
              ),
              SizedBox(height: 10,),
          //slider section with daily specials
          Container(
            height: Dimensions.pageView-55,

            child: PageView.builder(
                controller: pageController,
                //length is through a list dart
                itemCount:listofvalue.length,
                itemBuilder: (context, index) {
                  //this codes for the differnece in size when sliders move
                  //creates bigger slider in center
                  return _buildPageItem(index);
                }),


          ),
          //imported dots slider
          new DotsIndicator(
            dotsCount: 5,
            position: _currPageValue,
            decorator: DotsDecorator(
              size: const Size.square(9.0),
              activeSize: const Size(18.0, 9.0),
              activeShape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
              activeColor: AppColors.mainColor,
            ),
          ),

          //popular text
          SizedBox(height: 20,),

          Container(
            margin: EdgeInsets.only(left: 30,),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                BigText(text: "Everyday Grab & Go Options:",color: Color(0xff1a247d))
              ],
            ),
          ),
              Divider(
                color: Colors.black26,
                height: 20,
                thickness: 2,
                indent: 30,
                endIndent: 30,
              ),
          //SizedBox(height: 20,),
          //list of food  and images
          Container(
            margin: EdgeInsets.only(left: 35, right: 35),

            child: Text(
              "Chicken Caesar Salad with Roll \nCheese Caesar Salad with Breadsticks\nTurkey and Cheese Deli Sandwich \nHummus Plate \nYogurt Grab N Go Lunch \nPretzel Snack Pack \nTuna Salad Snack Pack \nChicken Salad Protein Pack \nProtein Pack Lunch \nEgg Salad Stack Pack\nVegan Chickpea Salad Sandwich \nBlack Bean Grain Bowl with Ranch Cilantro Lime Dressing",
            style: TextStyle(
              fontSize: 18,
              height: 1.5,
            ),
            )
          ),

              //second food type
              SizedBox(height: 20,),

              Container(
                margin: EdgeInsets.only(left: 30,),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    BigText(text: "Everyday Grill & Pizza Options:",color: Color(0xff1a247d))
                  ],
                ),
              ),
              Divider(
                color: Colors.black26,
                height: 20,
                thickness: 2,
                indent: 30,
                endIndent: 30,
              ),
              //SizedBox(height: 20,),
              //list of food  and images
              Container(
                  margin: EdgeInsets.only(left: 35, right: 35),

                  child: Text(
                    "Cheeseburger with French Fries\nGolden Crispy Chicken Burger with Fries\nSpicy Chicken Burger with French Fries\nVegetarian Burger with French Fries\nRolled Edge Pepperoni Pizza with Garden Salad\nRolled Edge Cheese Pizza with Garden Salad",
                    style: TextStyle(
                      fontSize: 18,
                      height: 1.5,
                    ),
                  )
              ),


              //third food
              SizedBox(height: 20,),

              Container(
                margin: EdgeInsets.only(left: 30,),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    BigText(text: "Everyday Other Side Options:",color: Color(0xff1a247d))
                  ],
                ),
              ),
              Divider(
                color: Colors.black26,
                height: 20,
                thickness: 2,
                indent: 30,
                endIndent: 30,
              ),
              //SizedBox(height: 20,),
              //list of food  and images
              Container(
                  margin: EdgeInsets.only(left: 35, right: 35),
                  child: Text(
                    "Salad Mix\nBroccoli\nBaby Carrots\nApple\nCanned Pears\nOrange Juice\nApple Juice\nDried Fruit\nChocolate Milk\n1% White Milk\nRanch Dressing\nKetchup\nMustard\nSuper Special Secret Sauce                           ",
                    style: TextStyle(
                      fontSize: 18,
                      height: 1.5,
                    ),
                  )
              ),

      ],
    ),
              ),

              ],
    );
  }

  Widget _buildPageItem(int index) {
    Matrix4 matrix = new Matrix4.identity();
    if (index == _currPageValue.floor()) {
      var currScale = 1 - (_currPageValue - index) * (1 - _scaleFactor);
      var currTrans = _height * (1 - currScale) / 2;
      matrix = Matrix4.diagonal3Values(1, currScale, 1)..setTranslationRaw(0, currTrans, 0);

    } else if (index == _currPageValue.floor() + 1) {
      var currScale = _scaleFactor +(_currPageValue - index + 1) * (1 - _scaleFactor);
      var currTrans = _height * (1 - currScale) / 2;
      matrix = Matrix4.diagonal3Values(1, currScale, 1);
      matrix = Matrix4.diagonal3Values(1, currScale, 1)..setTranslationRaw(0, currTrans, 0);

    } else if (index == _currPageValue.floor() - 1) {
      var currScale = 1-(_currPageValue - index) * (1 - _scaleFactor);
      var currTrans = _height * (1 - currScale) / 2;
      matrix = Matrix4.diagonal3Values(1, currScale, 1);
      matrix = Matrix4.diagonal3Values(1, currScale, 1)..setTranslationRaw(0, currTrans, 0);
    }else{
      //var currScale= 0.8;
      matrix = Matrix4.diagonal3Values(0, _height +(1-_scaleFactor)/2, 0);
    }

    return Transform(
      transform: matrix,
      child: Stack(

        children: [
          //the background 'food' part
          Container(
            height: Dimensions.pageViewContainer,

            margin: EdgeInsets.only(left: 10, right: 10,),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                color: index.isEven ? Color(0xFF69c5df) : Color(0xFF9294cc),
                image: DecorationImage(
                    fit: BoxFit.cover,
                    image: AssetImage(
                        listofvalue[index].imagepath,
                       // info[index]['img']
                    )
                  //image: NetworkImage(
                  //'https://resources.finalsite.net/images/f_auto,q_auto/v1598301388/nsdorg/idkqqo6txayykaolj84e/woodinville-homepage.jpg'
                  // ),


                )
            ),
          ),
          Align(
            //the commented white part
            alignment: Alignment.bottomCenter,
            child: Container(
              height: 50,
              width: Dimensions.pageViewTextContainerWidth,

              //creates space between next slide
              margin: EdgeInsets.only(left: 30, right:30,bottom: 10),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: Colors.white,
                  boxShadow:[
                    BoxShadow(
                        color: Color(0xFFe8e8e8),
                        blurRadius: 5.0,
                        offset: Offset(5,5)
                    ),
                    BoxShadow(
                      color: Colors.white,
                      offset: Offset(-5,0),
                    ),

                    BoxShadow(
                      color: Colors.white,
                      offset: Offset(5,0),
                    )
                  ]

              ),
              child: Container(
                padding: EdgeInsets.only(top: 15, left: 15, right: 15),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    BigText(text: listofvalue[index].title
                      //info[index]["title"]
                  ),
                   // SizedBox(height: 10,),
                  ],
                ),
              ),
            ),
          )

        ],
      ),
    );
  }

}

