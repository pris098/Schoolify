import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import '../main_page.dart';

class EmailPage extends StatefulWidget {
  const EmailPage({Key? key}) : super(key: key);

  @override
  State<EmailPage> createState() => _EmailPageState();
}

class _EmailPageState extends State<EmailPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(

        //background image
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage(
                "assets/image/btwo.png"),
            fit: BoxFit.cover,
          ),
        ),

        child: Column(
          children: [
            Container(
              margin: const EdgeInsets.only(top: 20, left: 30, right: 30),
              width: MediaQuery.of(context).size.width,
              height: 95,
              child: Column(
                children: [
                  //back arrow and profile
                  Row(
                    children: [
                      //back arrow
                      Expanded(child: Container()),

                      Container(
                        height: 50,
                        width: 50,

                        decoration: BoxDecoration(
                            image: DecorationImage(
                              alignment: Alignment.topCenter,

                              image: AssetImage(
                                  "assets/image/logo.png"
                              ),
                            )
                        ),
                      ),
                    ],
                  ),

                  Row(
                    children: [
                      //back arrow
                      GestureDetector(
                        onTap: (){
                          Get.to(()=>MainPage());
                        },
                        child: Icon(
                          Icons.arrow_back_ios, size: 30, color: Colors.white,),
                      ),
                      //space
                      SizedBox(width: 30,),
                      //title text
                      Text("Email",
                        style: TextStyle(
                            fontSize: 35,
                            color: Colors.white,
                            fontWeight: FontWeight.w800
                        ),
                      ),

                    ],
                  ),
                ],
              ),
            ),

            Expanded(child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topRight:Radius.circular(40),
                  topLeft: Radius.circular(40),
                ),
              ),
              child: Column(

                children: [
                  Container(
                      margin: EdgeInsets.only(left:30, right: 30, top:30),

                      child: Column(

                          children: [
                            Row(
                            children:[
                              SizedBox(height: 20,),

                              Text(
                              "Email of Staff/Teacher",
                                style: TextStyle(
                                  fontSize: 20,
                                  color: Colors.black45,
                                ),
                              ),
                      Expanded(child: Container()),
                    ],
                        ),



                            SizedBox(height: 5,),
                            Center(
                              child: Padding(
                                padding: const EdgeInsets.all(10),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    TextField(
                                      keyboardType: TextInputType.number,
                                      decoration: InputDecoration(
                                          hintText: '- -                                                                          @nsd.org'
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),

                            SizedBox(height: 20,),

                            Row(
                              children:[
                                Text(
                                  "Subject",
                                  style: TextStyle(
                                    fontSize: 20,
                                    color: Colors.black45,
                                  ),
                                ),
                                Expanded(child: Container()),
                              ],
                            ),
                            SizedBox(height: 5,),
                            Center(
                              child: Padding(
                                padding: const EdgeInsets.all(10),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    TextField(
                                      keyboardType: TextInputType.number,
                                      decoration: InputDecoration(
                                          hintText: '- -'
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),

                            SizedBox(height: 20,),

                            Row(
                              children:[
                                Text(
                                  "Write Note Below",
                                  style: TextStyle(
                                    fontSize: 20,
                                    color: Colors.black45,
                                  ),
                                ),
                                Expanded(child: Container()),
                              ],
                            ),


                            SizedBox(height: 5,),

                            Center(
                              child: Padding(
                                padding: const EdgeInsets.all(10),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      TextField(
                                        keyboardType: TextInputType.number,
                                        decoration: InputDecoration(
                                          hintText: '- -'
                                        ),
                                      )
                                    ],
                                ),
                              ),
                            ),


                            SizedBox(height: 50,),
                           Container(
                             alignment: Alignment.center,
                             width: 300,
                             height: 50,
                             decoration: BoxDecoration(
                               color: Color(0xff2855ae),
                               borderRadius: BorderRadius.circular(15),
                             ),

                             child: Text(
                               "SEND",
                               style: TextStyle(
                                 fontSize: 25,
                                 fontWeight: FontWeight.w300,
                                 color: Colors.white,
                               ),
                             ),
                           )

                          ]
                      )



                  ),
                ],
              ),
            ),
            ),
          ],
        ),
      ),
    );
  }
}
