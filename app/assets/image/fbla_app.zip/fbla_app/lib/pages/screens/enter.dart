import 'package:fbla_app/utils/dimensions.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import 'log.dart';

class EnterPage extends StatefulWidget {
  const EnterPage({Key? key}) : super(key: key);

  @override
  State<EnterPage> createState() => _EnterPageState();
}

class _EnterPageState extends State<EnterPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: Colors.white,
        child: Column(
          children: [
            SizedBox(height: 50),
            Row(
              children:[
                Expanded(child: Container(),),
                Container(
                  height: 225,
                  width: 225,
                  decoration: BoxDecoration(
                      image: DecorationImage(
                        alignment: Alignment.topCenter,
                        image: AssetImage("assets/image/logo.png"),
                      )),
                ),
                Expanded(child: Container(),),
              ],

            ),
            Container(
              height: 300,
              width: Dimensions.screenWidth,
              decoration: BoxDecoration(
                image: DecorationImage(
                  alignment: Alignment.center,
                  image: AssetImage("assets/image/school.png"),

                ),
              ),
            ),
            SizedBox(width: 20,),
            GestureDetector(
              onTap: (){
                Get.to(()=> LogIn());
              },
              child: Container(
                alignment: Alignment.center,
                width: 300,
                height: 50,
                decoration: BoxDecoration(
                  color: Color(0xff4bae28),
                  borderRadius: BorderRadius.circular(15),
                ),

                child: Row(
                    children:[
                      SizedBox(width: 100,),

                      Text(
                        "Get Started!",
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w300,
                          color: Colors.white,

                        ),
                      ),
                      SizedBox(width: 50,),
                      Icon(Icons.arrow_forward, color: Colors.white)
                    ]
                ),
              ),
            ),
          ],
        ),
      )

    );
  }
}
