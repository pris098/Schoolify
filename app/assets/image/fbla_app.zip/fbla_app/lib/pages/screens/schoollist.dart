import 'package:flutter/material.dart';

class SchoolModel {
  String school_title;

  SchoolModel(this.school_title);
}