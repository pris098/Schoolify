import 'dart:convert';

import 'package:dots_indicator/dots_indicator.dart';
import 'package:fbla_app/listvalues.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import '../../utils/colors.dart';
import '../../utils/dimensions.dart';
import '../../widgets/big_text.dart';
import '../main_page.dart';
import 'list.dart';
import 'log.dart';

class MotivePage extends StatefulWidget {
  const MotivePage({Key? key}) : super(key: key);

  @override
  State<MotivePage> createState() => _MotivePageState();
}

class _MotivePageState extends State<MotivePage> {
  //json stuff
  List info = [];
  _initData() {
    DefaultAssetBundle.of(context).loadString("json/info.json").then((value) {
      info = json.decode(value);
    });
  }

  PageController pageController = PageController(viewportFraction: 0.85);
  var _currPageValue = 0.0;
  double _scaleFactor = 0.8;
  double _height = Dimensions.pageViewContainer;

  //code for the differnce in height for scrollable feature
  @override
  void initState() {
    super.initState();
    _initData();

    pageController.addListener(() {
      setState(() {
        _currPageValue = pageController.page!;
        print("Current Value is " + info.length.toString());
      });
    });
  }

  @override
  void dispose() {
    pageController.dispose();
  }

  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        //background image
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage("assets/image/btwo.png"),
            fit: BoxFit.cover,
          ),
        ),

        child: Column(
          children: [
            Container(
              margin: const EdgeInsets.only(top: 20, left: 30, right: 30),
              width: MediaQuery.of(context).size.width,
              height: 95,
              child: Column(
                children: [
                  //back arrow and profile
                  Row(
                    children: [
                      //back arrow
                      Expanded(child: Container()),
                    ],
                  ),

                  Row(
                    children: [
                      //back arrow
                      GestureDetector(
                        onTap: () {
                          Get.to(() => LogIn());
                        },
                        child: Icon(
                          Icons.arrow_back_ios,
                          size: 30,
                          color: Colors.white,
                        ),
                      ),
                      //space
                      SizedBox(
                        width: 110,
                      ),
                      //title text
                      Container(
                        height: 95,
                        width: 70,
                        decoration: BoxDecoration(
                            image: DecorationImage(
                          alignment: Alignment.topCenter,
                          image: AssetImage("assets/image/logo.png"),
                        )),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Expanded(
              child: Container(
                width: Dimensions.screenWidth,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topRight: Radius.circular(40),
                    topLeft: Radius.circular(40),
                  ),
                ),

                child: Column(
                  children: [
                    SizedBox(height: 35,),
                    Text(
                      "Welcome to Schoolify!",
                      style: TextStyle(
                        fontSize: 35,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Text(
                      "One stop to simplify school!",
                      style: TextStyle(
                          fontSize: 19,
                          color: Colors.black38,
                        // fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(height: 44,),
                    Text(
                      "Your Motivational Quote of the Day:",
                      style: TextStyle(
                        fontSize: 22,
                       color: Color(0xff2c8092)
                       // fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(height: 15,),
                    Container(
                      height: Dimensions.pageView-25,

                      child: PageView.builder(
                          controller: pageController,
                          itemCount:list.length,
                          itemBuilder: (context, index) {
                            return _buildPageItem(index);
                          }),


                    ),
                    new DotsIndicator(
                      dotsCount: 5,
                      position: _currPageValue,
                      decorator: DotsDecorator(
                        size: const Size.square(9.0),
                        activeSize: const Size(18.0, 9.0),
                        activeShape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
                        activeColor: AppColors.mainColor,
                      ),
                    ),
                    SizedBox(height: 15,),

                    GestureDetector(
                      onTap: (){
                        Get.to(()=>MainPage());
                      },
                      child: Container(
                        alignment: Alignment.center,
                        width: 300,
                        height: 50,
                        decoration: BoxDecoration(
                          color: Color(0xff2855ae),
                          borderRadius: BorderRadius.circular(15),
                        ),


                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children:[

                            Text(
                              "Continue",
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w300,
                                color: Colors.white,
                              ),
                            ),
                            SizedBox(width: 7,),
                            Icon(Icons.arrow_forward, color: Colors.white)
                          ]
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPageItem(int index) {
    Matrix4 matrix = new Matrix4.identity();
    if (index == _currPageValue.floor()) {
      var currScale = 1 - (_currPageValue - index) * (1 - _scaleFactor);
      var currTrans = _height * (1 - currScale) / 2;
      matrix = Matrix4.diagonal3Values(1, currScale, 1)
        ..setTranslationRaw(0, currTrans, 0);
    } else if (index == _currPageValue.floor() + 1) {
      var currScale =
          _scaleFactor + (_currPageValue - index + 1) * (1 - _scaleFactor);
      var currTrans = _height * (1 - currScale) / 2;
      matrix = Matrix4.diagonal3Values(1, currScale, 1);
      matrix = Matrix4.diagonal3Values(1, currScale, 1)
        ..setTranslationRaw(0, currTrans, 0);
    } else if (index == _currPageValue.floor() - 1) {
      var currScale = 1 - (_currPageValue - index) * (1 - _scaleFactor);
      var currTrans = _height * (1 - currScale) / 2;
      matrix = Matrix4.diagonal3Values(1, currScale, 1);
      matrix = Matrix4.diagonal3Values(1, currScale, 1)
        ..setTranslationRaw(0, currTrans, 0);
    } else {
      var currScale = 0.8;
      matrix = Matrix4.diagonal3Values(0, _height + (1 - _scaleFactor) / 2, 0);
    }

    return Transform(
      transform: matrix,
      child: Stack(
        children: [
          //the background 'food' part
          Container(
            height: Dimensions.pageViewContainer+40,
            margin: EdgeInsets.only(
              left: 10,
              right: 10,
            ),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                color: index.isEven ? Colors.transparent : Colors.transparent,
                image: DecorationImage(
                    fit: BoxFit.contain, image: AssetImage(list[index].imagepath)
                    //image: NetworkImage(
                    //'https://resources.finalsite.net/images/f_auto,q_auto/v1598301388/nsdorg/idkqqo6txayykaolj84e/woodinville-homepage.jpg'
                    // ),

                    )),
          ),
          Align(
            //the commented white part
            alignment: Alignment.bottomCenter,
            child: Container(
              height: 50,
              width: Dimensions.pageViewTextContainerWidth,

              //creates space between next slide
              margin: EdgeInsets.only(left: 30, right: 30, bottom: 7),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: Color(0xffdbe2fd),
                  boxShadow: [
                    BoxShadow(
                        color: Color(0xFFe8e8e8),
                        blurRadius: 5.0,
                        offset: Offset(5, 5)),
                    BoxShadow(
                      color: Color(0xffdbe2fd),
                      offset: Offset(-5, 0),
                    ),
                    BoxShadow(
                      color: Color(0xffdbe2fd),
                      offset: Offset(5, 0),

                    )
                  ]),
              child: Container(
                padding: EdgeInsets.only(top: 15, left: 15, right: 15),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    BigText(text: list[index].title),
                    // SizedBox(height: 10,),
                  ],
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
