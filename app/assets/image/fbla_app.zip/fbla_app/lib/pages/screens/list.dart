import 'package:flutter/material.dart';

class ListValues {
  String imagepath;
  String title;

  ListValues(
      {
        required this.imagepath,
        required this.title});
}

var list = [
  new ListValues(
      imagepath: "assets/image/quote.png",
      title: "Swipe for ASB Updates"),

  new ListValues(
    imagepath: "assets/image/up3.png",
    title: "Next Week Spirit Week!",),
  new ListValues(
    imagepath: "assets/image/up2.png",
    title: "WHS Hall of Fame Induction",),
  new ListValues(
    imagepath: "assets/image/up1.png",
    title: "Class of 2023 Fundraiser",),
  new ListValues(
    imagepath: "assets/image/up4.png",
    title: "Join Link Crew today!",),


];