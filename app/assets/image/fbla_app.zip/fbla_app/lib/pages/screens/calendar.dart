import 'package:fbla_app/widgets/big_text.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import '../../utils/dimensions.dart';
import '../main_page.dart';

class CalPage extends StatefulWidget {
  const CalPage({Key? key}) : super(key: key);

  @override
  State<CalPage> createState() => _CalPageState();
}

class _CalPageState extends State<CalPage> {

  late Image img;
  late Image ap;
  late Image may;
  var month;

  @override
  void initState() {
    super.initState();
    ap = Image.asset("assets/image/april.png");
    may = Image.asset("assets/image/may1.png");
   img = ap;
   month= "April 2022";
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(

        //background image
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage(
                "assets/image/btwo.png"),
            fit: BoxFit.cover,
          ),
        ),

        child: Column(
          children: [
            Container(
              margin: const EdgeInsets.only(top: 20, left: 30, right: 30),
              width: MediaQuery.of(context).size.width,
              height: 95,
              child: Column(
                children: [
                  //back arrow and profile
                  Row(
                    children: [
                      //back arrow
                      Expanded(child: Container()),

                      Container(
                        height: 50,
                        width: 50,

                        decoration: BoxDecoration(
                            image: DecorationImage(
                              alignment: Alignment.topCenter,

                              image: AssetImage(
                                  "assets/image/logo.png"
                              ),
                            )
                        ),
                      ),
                    ],
                  ),




                  Row(
                    children: [
                      //back arrow
                      GestureDetector(
                        onTap: (){
                          Get.to(()=>MainPage());
                        },
                        child: Icon(
                          Icons.arrow_back_ios, size: 30, color: Colors.white,),
                      ),
                      //space
                      SizedBox(width: 30,),
                      //title text
                      Text("Calendar",
                        style: TextStyle(
                            fontSize: 35,
                            color: Colors.white,
                            fontWeight: FontWeight.w800
                        ),
                      ),

                    ],
                  ),
                ],
              ),
            ),

            Expanded(child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topRight:Radius.circular(40),
                  topLeft: Radius.circular(40),
                ),
              ),

              child: Column(

                children: [
                  Container(
                    margin: EdgeInsets.only(left:30, right: 30, top:10),

                    child: Column(
                      children: [
                        Stack(
                            children: [
                              Align(
                                alignment: Alignment.topCenter,
                                child: Container(
                                   // margin: EdgeInsets.only(left:200, right: 200, top:10),

                                    width: 140,
                                    height: 30,

                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(20),
                                    color: Color(0xff91b0ea),

                                  ),


                                  child: Align(
                                    alignment: Alignment.centerRight,
                                    child: Text(
                                      "Year   ",
                                      style: TextStyle(fontSize: 20,fontWeight: FontWeight.w500,),
                                    ),
                                  )
                            ),

                              ),

                              Align(
                                alignment: Alignment.centerLeft,

                                child: Container(
                                    margin: EdgeInsets.only(left:100, right: 100),
                                    width: 80,
                                    height: 30,

                                    decoration: BoxDecoration(
                                      color: Color(0xffb8caec),
                                      borderRadius: BorderRadius.circular(20),
                                    ),
                                    child: Align(
                                      alignment: Alignment.center,
                                      child: Text(
                                        "Month",
                                        style: TextStyle(fontSize: 20,fontWeight: FontWeight.w500,),
                                      ),
                                    )

                                ),
                              ),
                            ],
                          ),
                        SizedBox(height: 10,),

                        Row(

                          children: [
                            Icon(Icons.arrow_back_ios, size: 20, color: Colors.black,),
                            Expanded(child: Container()),
                            BigText(text: month),
                            Expanded(child: Container()),
                            GestureDetector(
                              child: Icon(Icons.arrow_forward_ios, size: 20, color: Colors.black,),


                              onTap: (){
                                setState(() {
                                  img= may;
                                  month= "May 2022";
                                });

                              },
                            ),

                          ],
                        ),
                      ]
                    )



                  ),

                  Row(
                    children: [
                      SizedBox(height: 10,),
                    Container(
                        margin: EdgeInsets.only(left:25, right: 25,),

                        height: 495,
                        width: Dimensions.screenWidth-50,
                       child:  img,
                        decoration: BoxDecoration(

                            ),

                            ),




                    ],
                  ),
                ],
            ),
            ),
            ),
          ],
        ),
      ),
    );
  }
  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties.add(DiagnosticsProperty<Image>('img', img));
  }
}
