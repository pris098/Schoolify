import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import '../main_page.dart';
import 'lunch_body.dart';

class LunchPage extends StatefulWidget {
  const LunchPage({Key? key}) : super(key: key);

  @override
  State<LunchPage> createState() => _LunchPageState();
}

class _LunchPageState extends State<LunchPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(

        //background image
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage(
                "assets/image/btwo.png"),
            fit: BoxFit.cover,
          ),
        ),

        child: Column(
          children: [
            Container(
              margin: const EdgeInsets.only(top: 20, left: 30, right: 30),
              width: MediaQuery.of(context).size.width,
              height: 95,
              child: Column(
                children: [
                  //back arrow and profile
                  Row(
                    children: [
                      //back arrow
                      Expanded(child: Container()),

                      Container(
                        height: 50,
                        width: 50,

                        decoration: BoxDecoration(
                            image: DecorationImage(
                              alignment: Alignment.topCenter,

                              image: AssetImage(
                                  "assets/image/logo.png"
                              ),
                            )
                        ),
                      ),
                    ],
                  ),




                  Row(
                    children: [
                      //back arrow
                      GestureDetector(
                        onTap: (){
                          Get.to(()=>MainPage());
                        },
                        child: Icon(
                          Icons.arrow_back_ios, size: 30, color: Colors.white,),
                      ),
                      //space
                      SizedBox(width: 30,),
                      //title text
                      Text("Lunch Menu",
                        style: TextStyle(
                            fontSize: 35,
                            color: Colors.white,
                            fontWeight: FontWeight.w800
                        ),
                      ),

                    ],
                  ),
                ],
              ),
            ),


              //showing the body
              Expanded(child: SingleChildScrollView(
                child: LunchBody(),
              ),),
          ],
        ),
      ),
    );


  }

}

