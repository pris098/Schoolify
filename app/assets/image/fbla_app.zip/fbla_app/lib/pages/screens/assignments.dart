import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:dotted_line/dotted_line.dart';

import '../main_page.dart';
import 'assignments2.dart';

class AssignPage extends StatefulWidget {
  const AssignPage({Key? key}) : super(key: key);

  @override
  State<AssignPage> createState() => _AssignPageState();
}

class _AssignPageState extends State<AssignPage> {
  late Color good;
  late Color blank;
  late Color col;
  late Color out;
  late Color dark;
  late Color nor;

  @override
  void initState() {
    super.initState();
    blank = Colors.white;
    good = Colors.lightGreenAccent;
    col= blank;
    dark= Colors.green;
    nor = Colors.black26;
    out = nor;
  }

  Widget build(BuildContext context) {

    return Scaffold(
      body: Container(

        //background image
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage(
                "assets/image/btwo.png"),
            fit: BoxFit.cover,
          ),
        ),

        child: Column(
          children: [
            Container(
              margin: const EdgeInsets.only(top: 20, left: 30, right: 30),
              width: MediaQuery.of(context).size.width,
              height: 95,
              child: Column(
                children: [
                  //back arrow and profile
                  Row(
                    children: [
                      //back arrow
                      Expanded(child: Container()),

                      Container(
                        height: 50,
                        width: 50,

                        decoration: BoxDecoration(
                            image: DecorationImage(
                              alignment: Alignment.topCenter,

                              image: AssetImage(
                                  "assets/image/logo.png"
                              ),
                            )
                        ),
                      ),
                    ],
                  ),




                  Row(
                    children: [
                      //back arrow
                      GestureDetector(
                        onTap: (){
                          Get.to(()=>MainPage());
                        },
                        child: Icon(
                          Icons.arrow_back_ios, size: 30, color: Colors.white,),
                      ),
                      //space
                      SizedBox(width: 30,),
                      //title text
                      Text("Assignments",
                        style: TextStyle(
                            fontSize: 35,
                            color: Colors.white,
                            fontWeight: FontWeight.w800
                        ),
                      ),

                    ],
                  ),
                ],
              ),
            ),

            Expanded(child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topRight:Radius.circular(40),
                  topLeft: Radius.circular(40),
                ),
              ),
                child: Column(

                children: [
                  Container(
                  margin: EdgeInsets.only(left:30, right: 30, top:30),

                  child: Column(

                  children: [
                    Row(
                      children:[
                        SizedBox(height: 20,),

                        Text(
                          "Satuday, April 23, 2022",
                          style: TextStyle(
                            fontSize: 20,
                            color: Color(0xff1faa7a),
                          ),
                        ),

                      ],
                    ),
                    SizedBox(height: 10,),
                    DottedLine(),
                    SizedBox(height: 12,),
                    GestureDetector(
                      onTap: (){
                        setState(() {
                          col = good;
                          out = dark;
                        },);

                      },
                      child: Stack(
                        children:[
                          Container(
                            height:50,
                            width: 400,

                            decoration: BoxDecoration(
                                color: col,
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(width: 2, color: out)

                            ),
                          ),

                          Column(
                            children: [
                              SizedBox(height: 10,),
                              Row(

                                children:[
                                  SizedBox(width: 20,),
                                  Text(
                                    "News Article Analysis",
                                    style: TextStyle(
                                      fontSize: 20,
                                      color: Colors.black45,
                                    ),
                                  ),

                                  Expanded(child: Container()),

                                  Container(
                                    height: 30,
                                    width: 30,

                                    decoration: BoxDecoration(
                                      color: col,
                                        borderRadius: BorderRadius.circular(20),
                                        border: Border.all(width: 2, color: out)

                                    ),
                                  ),
                                  SizedBox(width: 20,),

                                ],
                              ),
                            ],
                          ),



                        ],
                      ),
                    ),
                    SizedBox(height: 5,),
                    Stack(
                      children:[
                        Container(
                          height:50,
                          width: 400,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(width: 2, color: Colors.black26)

                          ),
                        ),

                        Column(
                          children: [
                            SizedBox(height: 10,),
                            Row(

                              children:[
                                SizedBox(width: 20,),
                                Text(
                                  "Math Hw #1",
                                  style: TextStyle(
                                    fontSize: 20,
                                    color: Colors.black45,
                                  ),
                                ),

                                Expanded(child: Container()),

                                Container(
                                  height: 30,
                                  width: 30,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(20),
                                      border: Border.all(width: 2, color: Colors.black26)

                                  ),
                                ),
                                SizedBox(width: 20,),

                              ],
                            ),
                          ],
                        ),



                      ],
                    ),
                    SizedBox(height: 40),

                    Container(
                      alignment: Alignment.topLeft,
                      child:
                      Text(
                        "Monday, April 25, 2022",
                        style: TextStyle(

                          fontSize: 20,
                          color: Color(0xff1faa7a),
                        ),
                      ),
                    ),
                    SizedBox(height: 10,),
                    DottedLine(),
                    SizedBox(height: 12,),
                    Stack(
                      children:[
                        Container(
                          height:50,
                          width: 400,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(width: 2, color: Colors.black26)

                          ),
                        ),

                        Column(
                          children: [
                            SizedBox(height: 10,),
                            Row(

                              children:[
                                SizedBox(width: 20,),
                                Text(
                                  "English Prose Essay",
                                  style: TextStyle(
                                    fontSize: 20,
                                    color: Colors.black45,
                                  ),
                                ),

                                Expanded(child: Container()),

                                Container(
                                  height: 30,
                                  width: 30,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(20),
                                      border: Border.all(width: 2, color: Colors.black26)

                                  ),
                                ),
                                SizedBox(width: 20,),

                              ],
                            ),
                          ],
                        ),



                      ],
                    ),
                    SizedBox(height: 5,),
                    Stack(
                      children:[
                        Container(
                          height:50,
                          width: 400,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(width: 2, color: Colors.black26)

                          ),
                        ),

                        Column(
                          children: [
                            SizedBox(height: 10,),
                            Row(

                              children:[
                                SizedBox(width: 20,),
                                Text(
                                  "Math Hw #2",
                                  style: TextStyle(
                                    fontSize: 20,
                                    color: Colors.black45,
                                  ),
                                ),

                                Expanded(child: Container()),

                                Container(
                                  height: 30,
                                  width: 30,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(20),
                                      border: Border.all(width: 2, color: Colors.black26)

                                  ),
                                ),
                                SizedBox(width: 20,),

                              ],
                            ),
                          ],
                        ),



                      ],
                    ),
                    SizedBox(height: 5,),
                    Stack(
                      children:[
                        Container(
                          height:50,
                          width: 400,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(width: 2, color: Colors.black26)

                          ),
                        ),

                        Column(
                          children: [
                            SizedBox(height: 10,),
                            Row(

                              children:[
                                SizedBox(width: 20,),
                                Text(
                                  "Lab Write Up",
                                  style: TextStyle(
                                    fontSize: 20,
                                    color: Colors.black45,
                                  ),
                                ),

                                Expanded(child: Container()),

                                Container(
                                  height: 30,
                                  width: 30,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(20),
                                      border: Border.all(width: 2, color: Colors.black26)

                                  ),
                                ),
                                SizedBox(width: 20,),

                              ],
                            ),
                          ],
                        ),



                      ],
                    ),
                    SizedBox(height: 50),
              SizedBox(height: 10,),
                    GestureDetector(
                      onTap: (){
                        Get.to(()=>AssignTwo());
                      },
                      child: Icon(
                        Icons.add_circle, size: 70, color: Color(0xff2855ae),),
                    ),

                  ],
                  ),
                  ),
                ],
                ),
            ),
            ),
          ],
        ),
      ),
    );
  }
}
