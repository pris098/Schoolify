import 'package:dotted_line/dotted_line.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import '../main_page.dart';
import 'assignments.dart';

class AssignTwo extends StatefulWidget {
  const AssignTwo({Key? key}) : super(key: key);

  @override
  State<AssignTwo> createState() => _AssignTwoState();
}

class _AssignTwoState extends State<AssignTwo> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(

        //background image
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage(
                "assets/image/btwo.png"),
            fit: BoxFit.cover,
          ),
        ),

        child: Column(
          children: [
            Container(
              margin: const EdgeInsets.only(top: 20, left: 30, right: 30),
              width: MediaQuery.of(context).size.width,
              height: 95,
              child: Column(
                children: [
                  //back arrow and profile
                  Row(
                    children: [
                      //back arrow
                      Expanded(child: Container()),

                      Container(
                        height: 50,
                        width: 50,

                        decoration: BoxDecoration(
                            image: DecorationImage(
                              alignment: Alignment.topCenter,

                              image: AssetImage(
                                  "assets/image/logo.png"
                              ),
                            )
                        ),
                      ),
                    ],
                  ),




                  Row(
                    children: [
                      //back arrow
                      GestureDetector(
                        onTap: (){
                          Get.to(()=>MainPage());
                        },
                        child: Icon(
                          Icons.arrow_back_ios, size: 30, color: Colors.white,),
                      ),
                      //space
                      SizedBox(width: 30,),
                      //title text
                      Text("Assignments",
                        style: TextStyle(
                            fontSize: 35,
                            color: Colors.white,
                            fontWeight: FontWeight.w800
                        ),
                      ),

                    ],
                  ),
                ],
              ),
            ),

            Stack(
                children:[
                  Expanded(child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white30,
                      borderRadius: BorderRadius.only(
                        topRight:Radius.circular(40),
                        topLeft: Radius.circular(40),
                      ),
                    ),
                    child: Column(

                      children: [
                        Container(
                          margin: EdgeInsets.only(left:30, right: 30, top:30),

                          child: Column(

                            children: [
                              Row(
                                children:[
                                  SizedBox(height: 20,),

                                  Text(
                                    "Satuday, April 23, 2022",
                                    style: TextStyle(
                                      fontSize: 20,
                                      color: Color(0xff1faa7a),
                                    ),
                                  ),

                                ],
                              ),
                              SizedBox(height: 10,),
                              DottedLine(),
                              SizedBox(height: 12,),
                              Stack(
                                children:[
                                  Container(
                                    height:50,
                                    width: 400,
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(12),
                                        border: Border.all(width: 2, color: Colors.black26)

                                    ),
                                  ),

                                  Column(
                                    children: [
                                      SizedBox(height: 10,),
                                      Row(

                                        children:[
                                          SizedBox(width: 20,),
                                          Text(
                                            "News Article Analysis",
                                            style: TextStyle(
                                              fontSize: 20,
                                              color: Colors.black45,
                                            ),
                                          ),

                                          Expanded(child: Container()),

                                          Container(
                                            height: 30,
                                            width: 30,
                                            decoration: BoxDecoration(
                                                borderRadius: BorderRadius.circular(20),
                                                border: Border.all(width: 2, color: Colors.black26)

                                            ),
                                          ),
                                          SizedBox(width: 20,),

                                        ],
                                      ),
                                    ],
                                  ),



                                ],
                              ),
                              SizedBox(height: 5,),
                              Stack(
                                children:[
                                  Container(
                                    height:50,
                                    width: 400,
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(12),
                                        border: Border.all(width: 2, color: Colors.black26)

                                    ),
                                  ),

                                  Column(
                                    children: [
                                      SizedBox(height: 10,),
                                      Row(

                                        children:[
                                          SizedBox(width: 20,),
                                          Text(
                                            "Math Hw #1",
                                            style: TextStyle(
                                              fontSize: 20,
                                              color: Colors.black45,
                                            ),
                                          ),

                                          Expanded(child: Container()),

                                          Container(
                                            height: 30,
                                            width: 30,
                                            decoration: BoxDecoration(
                                                borderRadius: BorderRadius.circular(20),
                                                border: Border.all(width: 2, color: Colors.black26)

                                            ),
                                          ),
                                          SizedBox(width: 20,),

                                        ],
                                      ),
                                    ],
                                  ),



                                ],
                              ),
                              SizedBox(height: 40),

                              Container(
                                alignment: Alignment.topLeft,
                                child:
                                Text(
                                  "Monday, April 25, 2022",
                                  style: TextStyle(

                                    fontSize: 20,
                                    color: Color(0xff1faa7a),
                                  ),
                                ),
                              ),
                              SizedBox(height: 10,),
                              DottedLine(),
                              SizedBox(height: 12,),
                              Stack(
                                children:[
                                  Container(
                                    height:50,
                                    width: 400,
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(12),
                                        border: Border.all(width: 2, color: Colors.black26)

                                    ),
                                  ),

                                  Column(
                                    children: [
                                      SizedBox(height: 10,),
                                      Row(

                                        children:[
                                          SizedBox(width: 20,),
                                          Text(
                                            "English Prose Essay",
                                            style: TextStyle(
                                              fontSize: 20,
                                              color: Colors.black45,
                                            ),
                                          ),

                                          Expanded(child: Container()),

                                          Container(
                                            height: 30,
                                            width: 30,
                                            decoration: BoxDecoration(
                                                borderRadius: BorderRadius.circular(20),
                                                border: Border.all(width: 2, color: Colors.black26)

                                            ),
                                          ),
                                          SizedBox(width: 20,),

                                        ],
                                      ),
                                    ],
                                  ),



                                ],
                              ),
                              SizedBox(height: 5,),
                              Stack(
                                children:[
                                  Container(
                                    height:50,
                                    width: 400,
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(12),
                                        border: Border.all(width: 2, color: Colors.black26)

                                    ),
                                  ),

                                  Column(
                                    children: [
                                      SizedBox(height: 10,),
                                      Row(

                                        children:[
                                          SizedBox(width: 20,),
                                          Text(
                                            "Math Hw #2",
                                            style: TextStyle(
                                              fontSize: 20,
                                              color: Colors.black45,
                                            ),
                                          ),

                                          Expanded(child: Container()),

                                          Container(
                                            height: 30,
                                            width: 30,
                                            decoration: BoxDecoration(
                                                borderRadius: BorderRadius.circular(20),
                                                border: Border.all(width: 2, color: Colors.black26)

                                            ),
                                          ),
                                          SizedBox(width: 20,),

                                        ],
                                      ),
                                    ],
                                  ),



                                ],
                              ),
                              SizedBox(height: 5,),
                              Stack(
                                children:[
                                  Container(
                                    height:50,
                                    width: 400,
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(12),
                                        border: Border.all(width: 2, color: Colors.black26)

                                    ),
                                  ),

                                  Column(
                                    children: [
                                      SizedBox(height: 10,),
                                      Row(

                                        children:[
                                          SizedBox(width: 20,),
                                          Text(
                                            "Lab Write Up",
                                            style: TextStyle(
                                              fontSize: 20,
                                              color: Colors.black45,
                                            ),
                                          ),

                                          Expanded(child: Container()),

                                          Container(
                                            height: 30,
                                            width: 30,
                                            decoration: BoxDecoration(
                                                borderRadius: BorderRadius.circular(20),
                                                border: Border.all(width: 2, color: Colors.black26)

                                            ),
                                          ),
                                          SizedBox(width: 20,),

                                        ],
                                      ),
                                    ],
                                  ),



                                ],
                              ),
                              SizedBox(height: 50),
                              SizedBox(height: 10,),

                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  ),


                    Column(
                      children:[
                        SizedBox(height: 268),
                        Container(
                          height:300,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.only(
                              topRight:Radius.circular(40),
                              topLeft: Radius.circular(40),
                            ),
                          ),
                          child: Column(

                            children: [
                              Container(
                                margin: EdgeInsets.only(left:30, right: 30, top:30),
                                    child: Column(

                                    children: [

                                      Row(
                                        children:[
                                          SizedBox(height: 20,),

                                          Text(
                                            "Due Date",
                                            style: TextStyle(
                                              fontSize: 17,
                                              color: Colors.black45,
                                            ),
                                          ),

                                        ],
                                      ),
                                      SizedBox(height: 10),
                                      Row(
                                          children:[
                                            Text(
                                              "   01 Jan 2022",
                                              style: TextStyle(
                                                fontSize: 20,
                                                color: Colors.black26,
                                              ),
                                            ),
                                            Expanded(child: Container()),
                                            Icon(
                                              Icons.calendar_today, size: 20
                                            ),
                                          ]

                                      ),
                                      SizedBox(height: 5,),
                                      Divider(
                                        color: Colors.black26,
                                        height: 20,
                                        thickness: 2,
                                        indent: 10,
                                        endIndent: 10,
                                      ),

                                      SizedBox(height: 15,),

                                      Row(
                                        children:[
                                          Text(
                                            "Assignment Name",
                                            style: TextStyle(
                                              fontSize: 17,
                                              color: Colors.black45,
                                            ),
                                          ),
                                          Expanded(child: Container()),
                                        ],
                                      ),

                                          SizedBox(height: 7,),

                                      Row(
                                        children:[
                                          Text(
                                            "   - -",
                                            style: TextStyle(
                                              fontSize: 20,
                                              color: Colors.black45,
                                              fontWeight: FontWeight.w300,
                                            ),
                                          ),
                                          Expanded(child: Container()),
                                        ],
                                      ),

                                          Divider(
                                          color: Colors.black26,
                                          height: 20,
                                          thickness: 2,
                                          indent: 10,
                                          endIndent: 10,
                                          ),
                                      SizedBox(height: 20),
                                      Container(
                                        alignment: Alignment.center,
                                        width: 300,
                                        height: 50,
                                        decoration: BoxDecoration(
                                          color: Color(0xff2855ae),
                                          borderRadius: BorderRadius.circular(15),
                                        ),

                                        child: Text(
                                          "Save & Finish",
                                          style: TextStyle(
                                            fontSize: 20,
                                            fontWeight: FontWeight.w300,
                                            color: Colors.white,
                                          ),
                                        ),
                                      ),
                                      GestureDetector(
                                        onTap:(){
                                          Get.to(()=>AssignPage());
                                        },
                                        child: Row(
                                            children: [
                                              SizedBox(width:125,height: 30),
                                              //homepage title text
                                              Center(
                                                  child: Align(
                                                      alignment: Alignment.bottomCenter,
                                                      child: Text(
                                                        "       Back",

                                                        style: TextStyle(
                                                            fontSize: 15,
                                                            color: Colors.black,
                                                            fontWeight: FontWeight.w600
                                                        ),
                                                      )
                                                  )
                                              )


                                            ]
                                        ),
                                      ),


                                    ],
                                    ),
                              ),
                            ],

                          ),
                        )

                      ],

                    ),


          ],
        ),

      ],
    ),
      ),
    );
  }
}
