import 'package:fbla_app/widgets/big_text.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import '../../utils/colors.dart';
import '../main_page.dart';
import 'homepage_body.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      body: Column(
        children: [
          //showing the headre
          Container(
            child: Container(

              child: Container(
                margin: EdgeInsets.only(top:45, bottom: 15),
                padding: EdgeInsets.only(left: 20, right: 20),

                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children:[
                    Row(
                      children:[
                        GestureDetector(

                          onTap: (){
                            Get.to(()=>MainPage());
                          },
                          child: Icon(

                            Icons.arrow_back_ios, size: 20, color: Colors.black,),
                        ),
                        BigText(text: "Bangladesh", color:AppColors.mainColor),
                        Icon(Icons.arrow_drop_down_sharp)
                        //SmallText(text: "City"),


                      ],
                    ),
                    Center(
                        child: Container(
                          width: 45,
                          height: 45,
                          child: Icon(Icons.search, color:Colors.white),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(15),
                            color: AppColors.mainColor,

                          ),
                        )


                    )
                  ],
                ),
              ),
            ),
          ),

          //showing the body
          Expanded(child: SingleChildScrollView(
            child: HomepageBody(),
          ))

        ],
      ),
    );
  }
}
