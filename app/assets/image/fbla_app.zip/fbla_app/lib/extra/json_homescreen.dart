/*
                  SizedBox(height: 5,),
                  Expanded(child: OverflowBox(
                    maxWidth: MediaQuery.of(context).size.width,
                    child: ListView.builder(
                        itemCount: info.length,
                        itemBuilder: (_, i) {
                          return Row(
                            children: [

                              //left side widgets
                              Container(
                                width: 170,
                                height: 125,
                                margin: EdgeInsets.only( left: 25, bottom: 17),

                                decoration: BoxDecoration(
                                  color: Color(0xffcbdce8),
                                  //0xffdbdbe7),
                                  borderRadius: BorderRadius.circular(30),
                                  image: DecorationImage(
                                    image: AssetImage(
                                        info[i]['img']
                                      //"assets/image/Calender.jpg"
                                    ),

                                  ),


                                  //shadow on side and botom
                                  boxShadow: [
                                    BoxShadow(
                                      blurRadius: 5,
                                      offset: Offset(5, 5),
                                      color: Color(0xffd0d0d0),
                                    ),
                                  ],


                                ),


                                child: Container(
                                  padding: EdgeInsets.only(top: 30, left: 30, right: 15),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      SizedBox(height: 5,),





                                      SizedBox(height: 10,),
                                    ],
                                  ),
                                ),


                              ),
                              //right side widgets
                              Container(
                                width: 170,
                                height: 125,
                                margin: EdgeInsets.only( left: 25, bottom: 17),

                                decoration: BoxDecoration(
                                  color: Color(0xffe5e9ee),
                                  //0xffdbdbe7),
                                  borderRadius: BorderRadius.circular(30),
                                  image: DecorationImage(
                                    image: AssetImage(
                                        info[i]['img']
                                      //"assets/image/Calender.jpg"
                                    ),

                                  ),


                                  //shadow on side and botom
                                  boxShadow: [
                                    BoxShadow(
                                      blurRadius: 5,
                                      offset: Offset(5, 5),
                                      color: Color(0xffd0d0d0),
                                    ),
                                  ],


                                ),


                                child: Container(
                                  padding: EdgeInsets.only(top: 30, left: 30, right: 15),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      SizedBox(height: 5,),





                                      SizedBox(height: 10,),
                                    ],
                                  ),
                                ),


                              ),

                          ],
                          );

                        }
                    ),
            ),
                  ),

                  */
