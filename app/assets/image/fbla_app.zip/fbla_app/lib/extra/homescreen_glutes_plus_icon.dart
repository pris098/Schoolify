/*Container(
width: 170,
height: 125,
margin: EdgeInsets.only(left: 20, bottom: 17,),

decoration: BoxDecoration(
color: Color(0xffdadbe5),
borderRadius: BorderRadius.circular(30),
image: DecorationImage(
fit: BoxFit.cover,
image: NetworkImage(
"https://images.unsplash.com/photo-1513628253939-010e64ac66cd?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=387&q=80",

)

),
//shadow on side and botom
boxShadow: [
BoxShadow(
blurRadius: 5,
offset: Offset(5, 5),
color: Color(0xffd0d0d0),
),
],


),
child: Container(
padding: EdgeInsets.only(top: 30, left: 30, right: 15),
child: Column(
crossAxisAlignment: CrossAxisAlignment.start,
children: [
Icon(Icons.list_alt, size: 50,color: Colors.white),
SizedBox(height: 5,),

Text(
"Glues",
style: TextStyle(
fontSize: 20,
color: Colors.white,
fontWeight: FontWeight.w500
),
),
],
)
)
),
*/