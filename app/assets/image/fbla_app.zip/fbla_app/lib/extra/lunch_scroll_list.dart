/*Container(
height: 900,
child: ListView.builder(
physics: NeverScrollableScrollPhysics(),
shrinkWrap: true,
itemCount: 10,
itemBuilder: (context, index){
return Container(
margin: EdgeInsets.only(left: Dimensions.width20, right: Dimensions.width20,bottom: Dimensions.height10),
child: Row(
children: [
Container(
width: 120,
height: 120,
decoration: BoxDecoration(
borderRadius: BorderRadius.circular(20),
color: Colors.white38,

image: DecorationImage(
fit: BoxFit.cover,
image: AssetImage(
"assets/image/food0.png"
)
)
),
),

//text container
Container(
height: 100,
width: 240,
decoration: BoxDecoration(
borderRadius: BorderRadius.only(
topRight: Radius.circular(Dimensions.radius20),
bottomRight: Radius.circular(Dimensions.radius20)
),
color: Colors.white,
),
child: Padding(
padding: EdgeInsets.only(left:25),
child: Column(
crossAxisAlignment: CrossAxisAlignment.start,
mainAxisAlignment: MainAxisAlignment.center,
children: [
BigText(text:"apples "),
],

),

),
)

],
)
);
}

)
),

 */