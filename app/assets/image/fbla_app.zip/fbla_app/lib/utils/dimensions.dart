import 'package:get/get.dart';

class Dimensions{
  static double screenHeight = Get.context!.height;
  static double screenWidth = Get.context!.width;
//
  static double pageView = screenHeight/2.225;
  static double pageViewContainer= screenHeight/3.25;
  static double pageViewTextContainer= screenHeight/7.0;
  static double pageViewTextContainerWidth= screenWidth/1.6;

  //dynamic height for pairing and margin
  static double height10 = screenHeight/84.4;
  static double height15 = screenHeight/56;
  static double height20 = screenHeight/33;
//dynamic width for paring and margin
  static double width10 = screenHeight/84.4;
  static double width15 = screenHeight/56;
  static double width20 = screenHeight/33;

  static double font20 = screenHeight/33;
  static double radius20 = screenHeight/33;
  static double radius30 = screenHeight/28;


}