import 'package:flutter/material.dart';

class ListValues {
  String imagepath;
  String title;

  ListValues(
  {
    required this.imagepath,
    required this.title});
}

var listofvalue = [
  new ListValues(
    imagepath: "assets/image/1.png",
    title: "Monday"),

  new ListValues(
      imagepath: "assets/image/2.png",
      title: "Tuesday",),
  new ListValues(
      imagepath: "assets/image/6.png",
    title: "Wednesday",),
  new ListValues(
      imagepath: "assets/image/5.png",
    title: "Thursday",),
  new ListValues(
      imagepath: "assets/image/7.png",
    title: "Friday",),


];